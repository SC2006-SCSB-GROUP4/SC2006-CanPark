import 'package:location/location.dart';

Future<LocationData?> getCurrentLocation() async {
  Location location = Location();
  try {
    LocationData locData = await location.getLocation();
    return locData;
  } catch (e) {
    print('Error when getting location: $e');
    return null;
  }
}
