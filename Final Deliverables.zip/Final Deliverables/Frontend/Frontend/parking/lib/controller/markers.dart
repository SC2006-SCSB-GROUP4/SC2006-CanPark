import 'dart:async';
import 'package:parking/main.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:parking/screens/modalBottomSheet.dart';
import 'package:flutter/services.dart' show rootBundle;

import 'package:parking/constants/constant.dart';

class CustomMarker {
  final MarkerId markerId;
  late BitmapDescriptor icon;
  final LatLng position;
  final InfoWindow
      infoWindow;
  final int availableLots;
  final String lotType;
  final String agency;

  CustomMarker(
      {required this.markerId,
      required this.position,
      required this.infoWindow,
      required this.availableLots,
      required this.lotType,
      required this.agency});
}

Future<CustomMarker> fetchOneCarparkInfo(String carparkId) async {
  final response =
      await http.get(Uri.parse('$carparkDBByIdConnect/$carparkId'));
  if (response.statusCode == 200) {
    final Map<String, dynamic> data = json.decode(response.body);

    final LatLng location = LatLng(
      data['latitude'] as double,
      data['longitude'] as double,
    );

    final CustomMarker customMarker = CustomMarker(
      markerId: MarkerId(data['CarParkID']),
      position: location,
      infoWindow: InfoWindow(
        title: data['Development'],
        snippet: data['Area'],
      ),
      availableLots: data['AvailableLots'],
      lotType: data['LotType'],
      agency: data['Agency'],
    );

    setCustomMarkerIcon(customMarker);

    return customMarker;
  } else {
    throw Exception('Failed to load car park info');
  }
}

Future<List<CustomMarker>> fetchCarparkInfo() async {
  // Loading from API Server
  final response = await http
      .get(Uri.parse(carparkDBConnect));
  if (response.statusCode == 200) {
    // If 200 OK response, parse JSON
    List<CustomMarker> customMarkers = parseCarparkInfo(response.body);
    for (var customMarker in customMarkers) {
      setCustomMarkerIcon(customMarker);
    }

    return customMarkers;
  } else {
    // Else, except
    throw Exception('Failed to load carpark data');
  }
}

List<CustomMarker> parseCarparkInfo(String jsonString) {
  final parsed = json.decode(jsonString);
  final List<dynamic> carparkInfo = parsed;

  if (settings.carparkAvailabilityFilter == 1) {
    List<CustomMarker> customMarkers = [];

    for (var data in carparkInfo) {
      final LatLng location = LatLng(
        (data['latitude']),
        (data['longitude']),
      );

      CustomMarker customMarker = CustomMarker(
        markerId: MarkerId(data['CarParkID']),
        position: location,
        infoWindow: InfoWindow(
          title: data['Development'],
          snippet: data['Area'],
        ),
        availableLots: data['AvailableLots'],
        lotType: data['LotType'],
        agency: data['Agency'],
      );

      // Initialize the icon field
      setCustomMarkerIcon(customMarker);

      customMarkers.add(customMarker);
    }
    return customMarkers;
  }

  if (settings.carparkAvailabilityFilter == 0) {
    if (settings.red == true &&
        settings.yellow == true &&
        settings.green == true) {
      List<dynamic> filteredCarparkInfo = carparkInfo;
      List<CustomMarker> customMarkers = [];

      for (var data in filteredCarparkInfo) {
        final LatLng location = LatLng(
          (data['latitude']),
          (data['longitude']),
        );

        CustomMarker customMarker = CustomMarker(
          markerId: MarkerId(data['CarParkID']),
          position: location,
          infoWindow: InfoWindow(
            title: data['Development'],
            snippet: data['Area'],
          ),
          availableLots: data['AvailableLots'],
          lotType: data['LotType'],
          agency: data['Agency'],
        );

        // Initialize the icon field
        setCustomMarkerIcon(customMarker);

        customMarkers.add(customMarker);
      }
      return customMarkers;
    }
  }

  if (settings.red == true &&
      settings.yellow == false &&
      settings.green == false) {
    List<dynamic> filteredCarparkInfo = carparkInfo;
    List<CustomMarker> customMarkers = [];

    for (var data in filteredCarparkInfo) {
      if ((data['AvailableLots']) < 50) {
        final LatLng location = LatLng(
          (data['latitude']),
          (data['longitude']),
        );

        CustomMarker customMarker = CustomMarker(
          markerId: MarkerId(data['CarParkID']),
          position: location,
          infoWindow: InfoWindow(
            title: data['Development'],
            snippet: data['Area'],
          ),
          availableLots: data['AvailableLots'],
          lotType: data['LotType'],
          agency: data['Agency'],
        );

        // Initialize the icon field
        setCustomMarkerIcon(customMarker);

        customMarkers.add(customMarker);
      }
    }
    return customMarkers;
  }

  if ((settings.green == true &&
      settings.yellow == true &&
      settings.red == false)) {
    List<dynamic> filteredCarparkInfo = carparkInfo;
    List<CustomMarker> customMarkers = [];

    for (var data in filteredCarparkInfo) {
      if ((data['AvailableLots']) >= 50) {
        final LatLng location = LatLng(
          (data['latitude']),
          (data['longitude']),
        );

        CustomMarker customMarker = CustomMarker(
          markerId: MarkerId(data['CarParkID']),
          position: location,
          infoWindow: InfoWindow(
            title: data['Development'],
            snippet: data['Area'],
          ),
          availableLots: data['AvailableLots'],
          lotType: data['LotType'],
          agency: data['Agency'],
        );

        // Initialize the icon field
        setCustomMarkerIcon(customMarker);

        customMarkers.add(customMarker);
      }
    }
    return customMarkers;
  }

  if ((settings.green == true &&
      settings.yellow == false &&
      settings.red == true)) {
    List<dynamic> filteredCarparkInfo = carparkInfo;
    List<CustomMarker> customMarkers = [];

    for (var data in filteredCarparkInfo) {
      if (((data['AvailableLots']) < 50) || ((data['AvailableLots']) >= 100)) {
        final LatLng location = LatLng(
          (data['latitude']),
          (data['longitude']),
        );

        CustomMarker customMarker = CustomMarker(
          markerId: MarkerId(data['CarParkID']),
          position: location,
          infoWindow: InfoWindow(
            title: data['Development'],
            snippet: data['Area'],
          ),
          availableLots: data['AvailableLots'],
          lotType: data['LotType'],
          agency: data['Agency'],
        );

        // Initialize the icon field
        setCustomMarkerIcon(customMarker);

        customMarkers.add(customMarker);
      }
    }
    return customMarkers;
  }

  if ((settings.yellow == true && settings.red == true)) {
    List<dynamic> filteredCarparkInfo = carparkInfo;
    List<CustomMarker> customMarkers = [];

    for (var data in filteredCarparkInfo) {
      if ((data['AvailableLots']) < 100) {
        final LatLng location = LatLng(
          (data['latitude']),
          (data['longitude']),
        );
        CustomMarker customMarker = CustomMarker(
          markerId: MarkerId(data['CarParkID']),
          position: location,
          infoWindow: InfoWindow(
            title: data['Development'],
            snippet: data['Area'],
          ),
          availableLots: data['AvailableLots'],
          lotType: data['LotType'],
          agency: data['Agency'],
        );

        // Initialize the icon field
        setCustomMarkerIcon(customMarker);

        customMarkers.add(customMarker);
      }
    }
    return customMarkers;
  }

  if (settings.green == true) {
    List<dynamic> filteredCarparkInfo = carparkInfo;
    List<CustomMarker> customMarkers = [];

    for (var data in filteredCarparkInfo) {
      if ((data['AvailableLots']) >= 100) {
        final LatLng location = LatLng(
          (data['latitude']),
          (data['longitude']),
        );

        CustomMarker customMarker = CustomMarker(
          markerId: MarkerId(data['CarParkID']),
          position: location,
          infoWindow: InfoWindow(
            title: data['Development'],
            snippet: data['Area'],
          ),
          availableLots: data['AvailableLots'],
          lotType: data['LotType'],
          agency: data['Agency'],
        );

        // Initialize the icon field
        setCustomMarkerIcon(customMarker);

        customMarkers.add(customMarker);
      }
    }
    return customMarkers;
  }

  if (settings.yellow == true) {
    List<dynamic> filteredCarparkInfo = carparkInfo;
    List<CustomMarker> customMarkers = [];

    for (var data in filteredCarparkInfo) {
      if ((data['AvailableLots']) < 100) {
        final LatLng location = LatLng(
          (data['latitude']),
          (data['longitude']),
        );

        CustomMarker customMarker = CustomMarker(
          markerId: MarkerId(data['CarParkID']),
          position: location,
          infoWindow: InfoWindow(
            title: data['Development'],
            snippet: data['Area'],
          ),
          availableLots: data['AvailableLots'],
          lotType: data['LotType'],
          agency: data['Agency'],
        );

        // Initialize the icon field
        setCustomMarkerIcon(customMarker);

        customMarkers.add(customMarker);
      }
    }
    return customMarkers;
  }

  if (settings.red == true) {
    List<dynamic> filteredCarparkInfo = carparkInfo;
    List<CustomMarker> customMarkers = [];

    for (var data in filteredCarparkInfo) {
      if ((data['AvailableLots']) < 50) {
        final LatLng location = LatLng(
          (data['latitude']),
          (data['longitude']),
        );

        CustomMarker customMarker = CustomMarker(
          markerId: MarkerId(data['CarParkID']),
          position: location,
          infoWindow: InfoWindow(
            title: data['Development'],
            snippet: data['Area'],
          ),
          availableLots: data['AvailableLots'],
          lotType: data['LotType'],
          agency: data['Agency'],
        );

        // Initialize the icon field
        setCustomMarkerIcon(customMarker);

        customMarkers.add(customMarker);
      }
    }
    return customMarkers;
  }
  print("No carpark information found");
  return [];
}

Future<void> setCustomMarkerIcon(CustomMarker customMarker) async {
  BitmapDescriptor? newIcon; // Declare as nullable
  if (customMarker.availableLots < 50) {
    newIcon = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration.empty, "assets/parkRed.png");
  } else if (customMarker.availableLots < 100) {
    newIcon = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration.empty, "assets/parkOrange.png");
  } else {
    newIcon = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration.empty, "assets/parkGreen.png");
  }

  Future<BitmapDescriptor> createTransparentBitmapDescriptor() async {
    final byteData = await rootBundle.load(
        'assets/transparent.png'); // Change the path to your transparent image
    final Uint8List byteList = byteData.buffer.asUint8List();
    return BitmapDescriptor.fromBytes(byteList);
  }
  
  customMarker.icon = newIcon ?? BitmapDescriptor.defaultMarker;
}

Marker customMarkerToMarker(
    BuildContext context,
    CustomMarker customMarker,
    LocationData? currentLocation,
    void Function(List<LatLng> newCoordinates) updatePolylineCallback,
    List<LatLng> polylineCoordinates) {
  return Marker(
      markerId: customMarker.markerId,
      icon: customMarker.icon,
      position: customMarker.position,
      infoWindow: customMarker.infoWindow,
      onTap: () {
        buildModalBottomSheet(context, customMarker, currentLocation,
            updatePolylineCallback, polylineCoordinates);
      });
}

void main() {
  fetchCarparkInfo();
}
