const String google_api_key = "AIzaSyDJRF14Oy3kwrqo2wLN50P7r5StFljj7Ak";

const String webConnect = 'http://20.0.2.2:8080';
const String userConnect = '$webConnect/users';
const String parkedConnect = '$webConnect/parkedLocation';
const String favConnect = '$webConnect/favourite';
const String prefConnect = '$webConnect/preference';
const String histConnect = '$webConnect/api/getHistory';
const String clearHist = '$webConnect/api/deleteHistory';
const String carparkDBConnect = '$webConnect/api/carParkdets/getAll';
const String carparkDBByIdConnect = '$webConnect/api/carParkdets/getById';
