import 'dart:math';
import 'package:google_maps_flutter/google_maps_flutter.dart';

double calculateDistance(LatLng start, LatLng end) {
  // Approximate Radius of the Earth
  const double earthRad = 6371.0;

  // Conversion of latitude and longitude from degrees to radians
  final double startLat = start.latitude * (pi / 180.0);
  final double startLng = start.longitude * (pi / 180.0);
  final double endLat = end.latitude * (pi / 180.0);
  final double endLng = end.longitude * (pi / 180.0);

  // Using the Haversine formula
  final double dLat = endLat - startLat;
  final double dLng = endLng - startLng;
  final double a = pow(sin(dLat / 2), 2) +
      cos(startLat) * cos(endLat) * pow(sin(dLng / 2), 2);
  final double c = 2 * atan2(sqrt(a), sqrt(1 - a));
  // Distance in kilometers
  final double distance = earthRad * c;

  return distance;
}
